// WorkLog 后端服务 - C++17/20 + cpp-httplib + SQLite
// 编译见项目根目录 Makefile / CMakeLists.txt / build.bat
#include <cstdio>
#include <ctime>
#include <mutex>
#include <random>
#include <string>
#include <vector>
#include <filesystem>
#include <fstream>
#include <sstream>

#include "third_party/httplib.h"
#include "third_party/sqlite3.h"
#include "sha256.h"
#include "json.h"

namespace fs = std::filesystem;
using mj::Json;

// ---------------- 全局配置 ----------------
static struct Config {
    int port = 8080;
    std::string host = "0.0.0.0";
    std::string db_path = "data/worklog.db";
    std::string public_dir = "public";
    int token_days = 7;
} g_cfg;

static sqlite3* g_db = nullptr;
static std::mutex g_db_mtx;

// ---------------- 工具函数 ----------------
static std::string randomHex(int bytes) {
    static thread_local std::mt19937_64 rng{std::random_device{}()};
    std::string out;
    char buf[3];
    for (int i = 0; i < bytes; i++) {
        snprintf(buf, 3, "%02x", (unsigned)(rng() & 0xFF));
        out += buf;
    }
    return out;
}

static std::string nowStr() {
    time_t t = time(nullptr);
    struct tm lt;
#ifdef _WIN32
    localtime_s(&lt, &t);
#else
    localtime_r(&t, &lt);
#endif
    char buf[32];
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &lt);
    return buf;
}

static std::string todayStr() {
    return nowStr().substr(0, 10);
}

static void sendJson(httplib::Response& res, const Json& j, int status = 200) {
    res.status = status;
    res.set_content(j.dump(), "application/json; charset=utf-8");
}

static void sendErr(httplib::Response& res, int status, const std::string& msg) {
    Json j = Json::makeObj();
    j["ok"] = Json::makeBool(false);
    j["error"] = Json::makeStr(msg);
    sendJson(res, j, status);
}

static std::string urlDecode(const std::string& in) {
    std::string out;
    for (size_t i = 0; i < in.size(); i++) {
        if (in[i] == '%' && i + 2 < in.size()) {
            out += char(strtol(in.substr(i + 1, 2).c_str(), nullptr, 16));
            i += 2;
        } else if (in[i] == '+') out += ' ';
        else out += in[i];
    }
    return out;
}

// UTF-8 字符串 <-> fs::path 跨平台转换（Windows 下正确处理中文路径）
static fs::path utf8Path(const std::string& s) {
    return fs::path(std::u8string(reinterpret_cast<const char8_t*>(s.c_str())));
}
static std::string pathUtf8(const fs::path& p) {
    std::u8string u = p.u8string();
    return std::string(reinterpret_cast<const char*>(u.c_str()));
}

// ---------------- 数据库 ----------------
static bool dbExec(const std::string& sql, std::string& err) {
    char* e = nullptr;
    if (sqlite3_exec(g_db, sql.c_str(), nullptr, nullptr, &e) != SQLITE_OK) {
        err = e ? e : "unknown";
        sqlite3_free(e);
        return false;
    }
    return true;
}

// RAII 语句
class Stmt {
public:
    Stmt(const std::string& sql) { sqlite3_prepare_v2(g_db, sql.c_str(), -1, &s_, nullptr); }
    ~Stmt() { if (s_) sqlite3_finalize(s_); }
    bool ok() const { return s_ != nullptr; }
    void bindInt(int i, long long v) { sqlite3_bind_int64(s_, i, v); }
    void bindStr(int i, const std::string& v) { sqlite3_bind_text(s_, i, v.c_str(), -1, SQLITE_TRANSIENT); }
    void bindNull(int i) { sqlite3_bind_null(s_, i); }
    bool step() { return sqlite3_step(s_) == SQLITE_ROW; }
    bool exec() { return sqlite3_step(s_) == SQLITE_DONE; }
    void reset() { if (s_) sqlite3_reset(s_); }
    long long colInt(int i) { return sqlite3_column_int64(s_, i); }
    std::string colStr(int i) {
        const unsigned char* t = sqlite3_column_text(s_, i);
        return t ? std::string((const char*)t) : std::string();
    }
    bool colNull(int i) { return sqlite3_column_type(s_, i) == SQLITE_NULL; }
private:
    sqlite3_stmt* s_ = nullptr;
};

static bool initDb(std::string& err) {
    fs::path p(g_cfg.db_path);
    if (p.has_parent_path() && !p.parent_path().empty()) fs::create_directories(p.parent_path());
    if (sqlite3_open_v2(g_cfg.db_path.c_str(), &g_db,
                        SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX, nullptr) != SQLITE_OK) {
        err = "无法打开数据库: " + g_cfg.db_path;
        return false;
    }
    const char* schema = R"SQL(
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  salt TEXT NOT NULL,
  created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS goals(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT DEFAULT '',
  level TEXT NOT NULL DEFAULT 'short',
  parent_id INTEGER,
  start_date TEXT DEFAULT '',
  due_date TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS daily_logs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  log_date TEXT NOT NULL,
  progress_md TEXT DEFAULT '',
  suggestion_md TEXT DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(user_id, log_date));
CREATE TABLE IF NOT EXISTS log_goals(
  log_id INTEGER NOT NULL,
  goal_id INTEGER NOT NULL,
  PRIMARY KEY(log_id, goal_id));
CREATE TABLE IF NOT EXISTS settings(
  user_id INTEGER NOT NULL,
  key TEXT NOT NULL,
  value TEXT DEFAULT '',
  PRIMARY KEY(user_id, key));
CREATE TABLE IF NOT EXISTS shares(
  share_id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  log_id INTEGER NOT NULL,
  created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_goals_user ON goals(user_id);
CREATE INDEX IF NOT EXISTS idx_logs_user ON daily_logs(user_id, log_date);
CREATE INDEX IF NOT EXISTS idx_shares_log ON shares(log_id);
)SQL";
    return dbExec(schema, err);
}

// ---------------- 认证 ----------------
// 从 Authorization 头 / Cookie / 查询参数取 token，校验后返回 user_id（0=未认证）
static long long authUser(const httplib::Request& req) {
    std::string token;
    std::string auth = req.get_header_value("Authorization");
    if (auth.rfind("Bearer ", 0) == 0) token = auth.substr(7);
    if (token.empty()) {
        std::string cookie = req.get_header_value("Cookie");
        size_t pos = cookie.find("wl_token=");
        if (pos != std::string::npos) {
            size_t st = pos + 9;
            size_t en = cookie.find(';', st);
            token = cookie.substr(st, en == std::string::npos ? std::string::npos : en - st);
        }
    }
    if (token.empty() && req.has_param("token")) token = req.get_param_value("token");
    if (token.empty()) return 0;

    std::lock_guard<std::mutex> lk(g_db_mtx);
    Stmt s("SELECT user_id, expires_at FROM sessions WHERE token=?");
    s.bindStr(1, token);
    if (!s.step()) return 0;
    long long uid = s.colInt(0);
    if (s.colStr(1) < nowStr()) return 0; // 过期
    return uid;
}

static std::string createSession(long long uid) {
    std::string token = randomHex(24);
    std::lock_guard<std::mutex> lk(g_db_mtx);
    time_t t = time(nullptr) + (time_t)g_cfg.token_days * 86400;
    struct tm lt;
#ifdef _WIN32
    localtime_s(&lt, &t);
#else
    localtime_r(&t, &lt);
#endif
    char buf[32];
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &lt);
    Stmt s("INSERT INTO sessions(token,user_id,created_at,expires_at) VALUES(?,?,?,?)");
    s.bindStr(1, token); s.bindInt(2, uid); s.bindStr(3, nowStr()); s.bindStr(4, buf);
    s.exec();
    return token;
}

static bool checkAuth(const httplib::Request& req, httplib::Response& res, long long& uid) {
    uid = authUser(req);
    if (uid == 0) { sendErr(res, 401, "未登录或登录已过期"); return false; }
    return true;
}

static Json parseBody(const httplib::Request& req, bool& ok) {
    Json j;
    ok = mj::tryParse(req.body, j);
    return j;
}

// ---------------- 分享页/导出 HTML 生成 ----------------
static std::string markedJsCache;
static bool markedLoaded = false;

static std::string loadMarkedJs() {
    if (!markedLoaded) {
        std::ifstream f(g_cfg.public_dir + "/vendor/marked.min.js", std::ios::binary);
        std::stringstream ss; ss << f.rdbuf();
        markedJsCache = ss.str();
        markedLoaded = true;
    }
    return markedJsCache;
}

static std::string htmlEscape(const std::string& s) {
    std::string out;
    for (char c : s) {
        if (c == '&') out += "&amp;";
        else if (c == '<') out += "&lt;";
        else if (c == '>') out += "&gt;";
        else if (c == '"') out += "&quot;";
        else out += c;
    }
    return out;
}

// 生成自包含 HTML 报告（内联 marked.js 渲染 Markdown）
static std::string buildReportHtml(const std::string& title, const std::string& date,
                                   const std::string& author,
                                   const std::string& progressMd, const std::string& suggestionMd,
                                   const std::vector<std::string>& goals) {
    Json dataJs = Json::makeObj(); // 用于安全注入 JSON
    dataJs["progress"] = Json::makeStr(progressMd);
    dataJs["suggestion"] = Json::makeStr(suggestionMd);
    std::string goalsList;
    for (auto& g : goals) goalsList += "<li>" + htmlEscape(g) + "</li>";
    std::string html = R"HTML(<!DOCTYPE html>
<html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>)HTML" + htmlEscape(title) + R"HTML(</title>
<style>
body{font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;background:#f4f6f9;margin:0;color:#2c3e50}
.wrap{max-width:820px;margin:32px auto;background:#fff;border-radius:12px;padding:36px 44px;box-shadow:0 2px 12px rgba(0,0,0,.08)}
h1{font-size:24px;margin:0 0 4px}
.meta{color:#8a94a6;font-size:13px;margin-bottom:24px}
h2{font-size:18px;border-left:4px solid #4a7cf7;padding-left:10px;margin:28px 0 12px}
.goals li{margin:4px 0;font-size:14px;color:#556}
.content{line-height:1.75;font-size:15px}
.content pre{background:#f6f8fa;padding:12px;border-radius:8px;overflow-x:auto}
.content code{background:#f0f2f5;padding:2px 5px;border-radius:4px;font-size:13px}
.content pre code{background:none;padding:0}
.content blockquote{border-left:3px solid #d5dbe5;margin:8px 0;padding:2px 14px;color:#667}
.content table{border-collapse:collapse}.content td,.content th{border:1px solid #dfe3ea;padding:6px 12px}
.empty{color:#aab2c0;font-style:italic}
</style></head><body><div class="wrap">
<h1>)HTML" + htmlEscape(title) + R"HTML(</h1>
<div class="meta">日期：)HTML" + htmlEscape(date) + "　作者：" + htmlEscape(author) + R"HTML(　生成时间：)HTML" + nowStr() + R"HTML(</div>
)HTML";
    if (!goals.empty()) html += "<h2>关联目标</h2><ul class=\"goals\">" + goalsList + "</ul>";
    html += "<h2>今日进展</h2><div class=\"content\" id=\"progress\"></div>";
    html += "<h2>建议</h2><div class=\"content\" id=\"suggestion\"></div>";
    html += "</div><script>" + loadMarkedJs() + "</script><script>var DATA=" + dataJs.dump() + R"HTML(;
function render(id,md){var el=document.getElementById(id);
if(md&&md.trim()){el.innerHTML=marked.parse(md);}else{el.innerHTML='<div class="empty">（无内容）</div>';}}
render('progress',DATA.progress);render('suggestion',DATA.suggestion);
</script></body></html>)HTML";
    return html;
}

// 查询某条日志的数据（含作者、关联目标）
struct LogData {
    bool found = false;
    long long log_id = 0, user_id = 0;
    std::string date, progress, suggestion, author;
    std::vector<std::string> goals;
};

static LogData loadLog(long long user_id, const std::string& date) {
    LogData d;
    std::lock_guard<std::mutex> lk(g_db_mtx);
    Stmt s("SELECT id, progress_md, suggestion_md FROM daily_logs WHERE user_id=? AND log_date=?");
    s.bindInt(1, user_id); s.bindStr(2, date);
    if (!s.step()) return d;
    d.found = true;
    d.log_id = s.colInt(0);
    d.progress = s.colStr(1);
    d.suggestion = s.colStr(2);
    d.date = date;
    d.user_id = user_id;
    Stmt u("SELECT username FROM users WHERE id=?");
    u.bindInt(1, user_id);
    if (u.step()) d.author = u.colStr(0);
    Stmt g("SELECT g.title FROM log_goals lg JOIN goals g ON g.id=lg.goal_id WHERE lg.log_id=?");
    g.bindInt(1, d.log_id);
    while (g.step()) d.goals.push_back(g.colStr(0));
    return d;
}

static std::string buildMarkdown(const LogData& d) {
    std::string md = "# 工作日报 " + d.date + "\n\n作者：" + d.author + "\n\n";
    if (!d.goals.empty()) {
        md += "## 关联目标\n\n";
        for (auto& g : d.goals) md += "- " + g + "\n";
        md += "\n";
    }
    md += "## 今日进展\n\n";
    md += d.progress.empty() ? "（无内容）\n" : d.progress + "\n";
    md += "\n## 建议\n\n";
    md += d.suggestion.empty() ? "（无内容）\n" : d.suggestion + "\n";
    return md;
}

// ---------------- 配置加载 ----------------
static void loadConfig() {
    std::ifstream f("config.json", std::ios::binary);
    if (!f) return;
    std::stringstream ss; ss << f.rdbuf();
    Json j;
    if (!mj::tryParse(ss.str(), j)) return;
    if (j.find("port")) g_cfg.port = (int)j.getNum("port", g_cfg.port);
    if (j.find("host")) g_cfg.host = j.getStr("host", g_cfg.host);
    if (j.find("db_path")) g_cfg.db_path = j.getStr("db_path", g_cfg.db_path);
    if (j.find("public_dir")) g_cfg.public_dir = j.getStr("public_dir", g_cfg.public_dir);
    if (j.find("token_days")) g_cfg.token_days = (int)j.getNum("token_days", g_cfg.token_days);
}

// ---------------- main ----------------
int main() {
    loadConfig();
    std::string err;
    if (!initDb(err)) { fprintf(stderr, "[错误] %s\n", err.c_str()); return 1; }

    httplib::Server svr;

    // ---- 认证 ----
    svr.Post("/api/register", [](const httplib::Request& req, httplib::Response& res) {
        bool ok; Json body = parseBody(req, ok);
        if (!ok) return sendErr(res, 400, "请求体不是合法 JSON");
        std::string u = body.getStr("username"), p = body.getStr("password");
        if (u.empty() || p.empty()) return sendErr(res, 400, "用户名和密码不能为空");
        if (u.size() > 32 || p.size() > 64) return sendErr(res, 400, "用户名≤32字符，密码≤64字符");
        std::string salt = randomHex(8);
        std::string hash = sha256::hex(salt + ":" + p);
        std::lock_guard<std::mutex> lk(g_db_mtx);
        Stmt chk("SELECT id FROM users WHERE username=?");
        chk.bindStr(1, u);
        if (chk.step()) return sendErr(res, 409, "用户名已存在");
        Stmt ins("INSERT INTO users(username,password_hash,salt,created_at) VALUES(?,?,?,?)");
        ins.bindStr(1, u); ins.bindStr(2, hash); ins.bindStr(3, salt); ins.bindStr(4, nowStr());
        if (!ins.exec()) return sendErr(res, 500, "注册失败");
        Json j = Json::makeObj();
        j["ok"] = Json::makeBool(true);
        j["user_id"] = Json::makeNum((double)sqlite3_last_insert_rowid(g_db));
        sendJson(res, j);
    });

    svr.Post("/api/login", [](const httplib::Request& req, httplib::Response& res) {
        bool ok; Json body = parseBody(req, ok);
        if (!ok) return sendErr(res, 400, "请求体不是合法 JSON");
        std::string u = body.getStr("username"), p = body.getStr("password");
        long long uid = 0;
        {
            std::lock_guard<std::mutex> lk(g_db_mtx);
            Stmt s("SELECT id, password_hash, salt FROM users WHERE username=?");
            s.bindStr(1, u);
            if (s.step()) {
                if (sha256::hex(s.colStr(2) + ":" + p) == s.colStr(1)) uid = s.colInt(0);
            }
        }
        if (uid == 0) return sendErr(res, 401, "用户名或密码错误");
        std::string token = createSession(uid);
        res.set_header("Set-Cookie", "wl_token=" + token + "; Max-Age=" +
                       std::to_string((long long)g_cfg.token_days * 86400) + "; Path=/; HttpOnly; SameSite=Lax");
        Json j = Json::makeObj();
        j["ok"] = Json::makeBool(true);
        j["token"] = Json::makeStr(token);
        j["username"] = Json::makeStr(u);
        sendJson(res, j);
    });

    svr.Post("/api/logout", [](const httplib::Request& req, httplib::Response& res) {
        std::string auth = req.get_header_value("Authorization");
        if (auth.rfind("Bearer ", 0) == 0) {
            std::lock_guard<std::mutex> lk(g_db_mtx);
            Stmt s("DELETE FROM sessions WHERE token=?");
            s.bindStr(1, auth.substr(7));
            s.exec();
        }
        Json j = Json::makeObj(); j["ok"] = Json::makeBool(true);
        sendJson(res, j);
    });

    svr.Get("/api/me", [](const httplib::Request& req, httplib::Response& res) {
        long long uid; if (!checkAuth(req, res, uid)) return;
        std::lock_guard<std::mutex> lk(g_db_mtx);
        Stmt s("SELECT username FROM users WHERE id=?");
        s.bindInt(1, uid);
        std::string un = s.step() ? s.colStr(0) : "";
        Json j = Json::makeObj();
        j["ok"] = Json::makeBool(true);
        j["username"] = Json::makeStr(un);
        sendJson(res, j);
    });

    // ---- 目标 ----
    svr.Get("/api/goals", [](const httplib::Request& req, httplib::Response& res) {
        long long uid; if (!checkAuth(req, res, uid)) return;
        Json list = Json::makeArr();
        std::lock_guard<std::mutex> lk(g_db_mtx);
        Stmt s("SELECT id,title,description,level,parent_id,start_date,due_date,status,created_at "
               "FROM goals WHERE user_id=? ORDER BY id");
        s.bindInt(1, uid);
        while (s.step()) {
            Json g = Json::makeObj();
            g["id"] = Json::makeNum((double)s.colInt(0));
            g["title"] = Json::makeStr(s.colStr(1));
            g["description"] = Json::makeStr(s.colStr(2));
            g["level"] = Json::makeStr(s.colStr(3));
            if (s.colNull(4)) g["parent_id"] = Json(); else g["parent_id"] = Json::makeNum((double)s.colInt(4));
            g["start_date"] = Json::makeStr(s.colStr(5));
            g["due_date"] = Json::makeStr(s.colStr(6));
            g["status"] = Json::makeStr(s.colStr(7));
            g["created_at"] = Json::makeStr(s.colStr(8));
            list.push(g);
        }
        Json j = Json::makeObj();
        j["ok"] = Json::makeBool(true);
        j["goals"] = list;
        sendJson(res, j);
    });

    svr.Post("/api/goals", [](const httplib::Request& req, httplib::Response& res) {
        long long uid; if (!checkAuth(req, res, uid)) return;
        bool ok; Json body = parseBody(req, ok);
        if (!ok) return sendErr(res, 400, "请求体不是合法 JSON");
        std::string title = body.getStr("title");
        if (title.empty()) return sendErr(res, 400, "目标标题不能为空");
        std::string level = body.getStr("level", "short");
        if (level != "long" && level != "mid" && level != "short") level = "short";
        std::lock_guard<std::mutex> lk(g_db_mtx);
        Stmt s("INSERT INTO goals(user_id,title,description,level,parent_id,start_date,due_date,status,created_at) "
               "VALUES(?,?,?,?,?,?,?,?,?)");
        s.bindInt(1, uid); s.bindStr(2, title); s.bindStr(3, body.getStr("description"));
        s.bindStr(4, level);
        const Json* pid = body.find("parent_id");
        if (pid && pid->type == Json::NUM) s.bindInt(5, (long long)pid->num); else s.bindNull(5);
        s.bindStr(6, body.getStr("start_date")); s.bindStr(7, body.getStr("due_date"));
        s.bindStr(8, "active"); s.bindStr(9, nowStr());
        if (!s.exec()) return sendErr(res, 500, "保存失败");
        Json j = Json::makeObj();
        j["ok"] = Json::makeBool(true);
        j["id"] = Json::makeNum((double)sqlite3_last_insert_rowid(g_db));
        sendJson(res, j);
    });

    svr.Put(R"(/api/goals/(\d+))", [&](const httplib::Request& req, httplib::Response& res) {
        long long uid; if (!checkAuth(req, res, uid)) return;
        long long gid = atoll(req.matches[1].str().c_str());
        bool ok; Json body = parseBody(req, ok);
        if (!ok) return sendErr(res, 400, "请求体不是合法 JSON");
        std::lock_guard<std::mutex> lk(g_db_mtx);
        {
            Stmt own("SELECT id FROM goals WHERE id=? AND user_id=?");
            own.bindInt(1, gid); own.bindInt(2, uid);
            if (!own.step()) return sendErr(res, 404, "目标不存在");
        }
        // 可更新字段：title description level parent_id start_date due_date status
        std::vector<std::string> sets;
        Stmt s("UPDATE goals SET title=COALESCE(?,title), description=COALESCE(?,description), "
               "level=COALESCE(?,level), start_date=COALESCE(?,start_date), due_date=COALESCE(?,due_date), "
               "status=COALESCE(?,status), parent_id=? WHERE id=? AND user_id=?");
        auto bindOpt = [&](int idx, const char* key) {
            const Json* v = body.find(key);
            if (v && v->type == Json::STR) s.bindStr(idx, v->str); else s.bindNull(idx);
        };
        bindOpt(1, "title"); bindOpt(2, "description"); bindOpt(3, "level");
        bindOpt(4, "start_date"); bindOpt(5, "due_date"); bindOpt(6, "status");
        const Json* pid = body.find("parent_id");
        if (pid) {
            if (pid->type == Json::NUM) s.bindInt(7, (long long)pid->num);
            else s.bindNull(7); // 显式传 null 解除父级
        } else {
            // 未传 parent_id 时保持不变
            Stmt cur("SELECT parent_id FROM goals WHERE id=?");
            cur.bindInt(1, gid);
            if (cur.step() && !cur.colNull(0)) s.bindInt(7, cur.colInt(0)); else s.bindNull(7);
        }
        s.bindInt(8, gid); s.bindInt(9, uid);
        if (!s.exec()) return sendErr(res, 500, "更新失败");
        Json j = Json::makeObj(); j["ok"] = Json::makeBool(true);
        sendJson(res, j);
    });

    svr.Delete(R"(/api/goals/(\d+))", [&](const httplib::Request& req, httplib::Response& res) {
        long long uid; if (!checkAuth(req, res, uid)) return;
        long long gid = atoll(req.matches[1].str().c_str());
        std::lock_guard<std::mutex> lk(g_db_mtx);
        Stmt own("SELECT parent_id FROM goals WHERE id=? AND user_id=?");
        own.bindInt(1, gid); own.bindInt(2, uid);
        if (!own.step()) return sendErr(res, 404, "目标不存在");
        bool hasParent = !own.colNull(0);
        long long pid = hasParent ? own.colInt(0) : 0;
        { // 子目标挂到被删目标的父级
            Stmt c("UPDATE goals SET parent_id=? WHERE parent_id=? AND user_id=?");
            if (hasParent) c.bindInt(1, pid); else c.bindNull(1);
            c.bindInt(2, gid); c.bindInt(3, uid); c.exec();
        }
        { Stmt l("DELETE FROM log_goals WHERE goal_id=?"); l.bindInt(1, gid); l.exec(); }
        { Stmt d("DELETE FROM goals WHERE id=? AND user_id=?"); d.bindInt(1, gid); d.bindInt(2, uid); d.exec(); }
        Json j = Json::makeObj(); j["ok"] = Json::makeBool(true);
        sendJson(res, j);
    });

    // ---- 日报 ----
    // GET /api/logs/2026-10-22
    svr.Get(R"(/api/logs/(\d{4}-\d{2}-\d{2}))", [&](const httplib::Request& req, httplib::Response& res) {
        long long uid; if (!checkAuth(req, res, uid)) return;
        std::string date = req.matches[1].str();
        Json j = Json::makeObj();
        j["ok"] = Json::makeBool(true);
        j["date"] = Json::makeStr(date);
        std::lock_guard<std::mutex> lk(g_db_mtx);
        Stmt s("SELECT id,progress_md,suggestion_md FROM daily_logs WHERE user_id=? AND log_date=?");
        s.bindInt(1, uid); s.bindStr(2, date);
        long long logId = 0;
        if (s.step()) {
            logId = s.colInt(0);
            j["found"] = Json::makeBool(true);
            j["progress_md"] = Json::makeStr(s.colStr(1));
            j["suggestion_md"] = Json::makeStr(s.colStr(2));
        } else {
            j["found"] = Json::makeBool(false);
            j["progress_md"] = Json::makeStr("");
            j["suggestion_md"] = Json::makeStr("");
        }
        Json gids = Json::makeArr();
        if (logId) {
            Stmt g("SELECT goal_id FROM log_goals WHERE log_id=?");
            g.bindInt(1, logId);
            while (g.step()) gids.push(Json::makeNum((double)g.colInt(0)));
        }
        j["goal_ids"] = gids;
        // 是否已分享
        if (logId) {
            Stmt sh("SELECT share_id FROM shares WHERE log_id=?");
            sh.bindInt(1, logId);
            if (sh.step()) j["share_id"] = Json::makeStr(sh.colStr(0));
        }
        sendJson(res, j);
    });

    // POST /api/logs/2026-10-22  (保存/更新)
    svr.Post(R"(/api/logs/(\d{4}-\d{2}-\d{2}))", [&](const httplib::Request& req, httplib::Response& res) {
        long long uid; if (!checkAuth(req, res, uid)) return;
        std::string date = req.matches[1].str();
        bool ok; Json body = parseBody(req, ok);
        if (!ok) return sendErr(res, 400, "请求体不是合法 JSON");
        std::string prog = body.getStr("progress_md"), sug = body.getStr("suggestion_md");
        std::lock_guard<std::mutex> lk(g_db_mtx);
        Stmt up("INSERT INTO daily_logs(user_id,log_date,progress_md,suggestion_md,created_at,updated_at) "
                "VALUES(?,?,?,?,?,?) "
                "ON CONFLICT(user_id,log_date) DO UPDATE SET progress_md=excluded.progress_md, "
                "suggestion_md=excluded.suggestion_md, updated_at=excluded.updated_at");
        up.bindInt(1, uid); up.bindStr(2, date); up.bindStr(3, prog); up.bindStr(4, sug);
        up.bindStr(5, nowStr()); up.bindStr(6, nowStr());
        if (!up.exec()) return sendErr(res, 500, "保存失败");
        Stmt q("SELECT id FROM daily_logs WHERE user_id=? AND log_date=?");
        q.bindInt(1, uid); q.bindStr(2, date);
        if (!q.step()) return sendErr(res, 500, "保存后读取失败");
        long long logId = q.colInt(0);
        { Stmt d("DELETE FROM log_goals WHERE log_id=?"); d.bindInt(1, logId); d.exec(); }
        const Json* gids = body.find("goal_ids");
        if (gids && gids->type == Json::ARR) {
            Stmt ins("INSERT OR IGNORE INTO log_goals(log_id,goal_id) "
                     "SELECT ?,id FROM goals WHERE id=? AND user_id=?");
            for (auto& g : gids->arr) {
                if (g.type == Json::NUM) {
                    ins.bindInt(1, logId); ins.bindInt(2, (long long)g.num); ins.bindInt(3, uid);
                    ins.exec();
                    ins.reset();
                }
            }
        }
        Json j = Json::makeObj();
        j["ok"] = Json::makeBool(true);
        j["log_id"] = Json::makeNum((double)logId);
        sendJson(res, j);
    });

    // GET /api/logs/list?month=2026-10
    svr.Get("/api/logs/list", [&](const httplib::Request& req, httplib::Response& res) {
        long long uid; if (!checkAuth(req, res, uid)) return;
        std::string month = req.has_param("month") ? req.get_param_value("month") : todayStr().substr(0, 7);
        Json list = Json::makeArr();
        std::lock_guard<std::mutex> lk(g_db_mtx);
        Stmt s("SELECT log_date FROM daily_logs WHERE user_id=? AND log_date LIKE ? ORDER BY log_date DESC");
        s.bindInt(1, uid); s.bindStr(2, month + "%");
        while (s.step()) list.push(Json::makeStr(s.colStr(0)));
        Json j = Json::makeObj();
        j["ok"] = Json::makeBool(true);
        j["month"] = Json::makeStr(month);
        j["dates"] = list;
        sendJson(res, j);
    });

    // GET /api/logs/DATE/export?format=md|html
    svr.Get(R"(/api/logs/(\d{4}-\d{2}-\d{2})/export)", [&](const httplib::Request& req, httplib::Response& res) {
        long long uid; if (!checkAuth(req, res, uid)) return;
        std::string date = req.matches[1].str();
        LogData d = loadLog(uid, date);
        if (!d.found) return sendErr(res, 404, "该日期没有日报");
        std::string fmt = req.has_param("format") ? req.get_param_value("format") : "md";
        if (fmt == "html") {
            std::string html = buildReportHtml("工作日报 " + date, date, d.author, d.progress, d.suggestion, d.goals);
            res.set_header("Content-Disposition", "attachment; filename=\"worklog-" + date + ".html\"");
            res.set_content(html, "text/html; charset=utf-8");
        } else {
            std::string md = buildMarkdown(d);
            res.set_header("Content-Disposition", "attachment; filename=\"worklog-" + date + ".md\"");
            res.set_content(md, "text/markdown; charset=utf-8");
        }
    });

    // ---- 分享 ----
    svr.Post(R"(/api/logs/(\d{4}-\d{2}-\d{2})/share)", [&](const httplib::Request& req, httplib::Response& res) {
        long long uid; if (!checkAuth(req, res, uid)) return;
        std::string date = req.matches[1].str();
        LogData d = loadLog(uid, date);
        if (!d.found) return sendErr(res, 404, "该日期没有日报，先保存再分享");
        std::lock_guard<std::mutex> lk(g_db_mtx);
        Stmt ex("SELECT share_id FROM shares WHERE log_id=?");
        ex.bindInt(1, d.log_id);
        std::string sid;
        if (ex.step()) sid = ex.colStr(0);
        else {
            sid = randomHex(10);
            Stmt ins("INSERT INTO shares(share_id,user_id,log_id,created_at) VALUES(?,?,?,?)");
            ins.bindStr(1, sid); ins.bindInt(2, uid); ins.bindInt(3, d.log_id); ins.bindStr(4, nowStr());
            if (!ins.exec()) return sendErr(res, 500, "生成分享失败");
        }
        Json j = Json::makeObj();
        j["ok"] = Json::makeBool(true);
        j["share_id"] = Json::makeStr(sid);
        j["url"] = Json::makeStr("/share/" + sid);
        sendJson(res, j);
    });

    svr.Delete(R"(/api/logs/(\d{4}-\d{2}-\d{2})/share)", [&](const httplib::Request& req, httplib::Response& res) {
        long long uid; if (!checkAuth(req, res, uid)) return;
        std::string date = req.matches[1].str();
        std::lock_guard<std::mutex> lk(g_db_mtx);
        Stmt s("DELETE FROM shares WHERE user_id=? AND log_id=(SELECT id FROM daily_logs WHERE user_id=? AND log_date=?)");
        s.bindInt(1, uid); s.bindInt(2, uid); s.bindStr(3, date);
        s.exec();
        Json j = Json::makeObj(); j["ok"] = Json::makeBool(true);
        sendJson(res, j);
    });

    // GET /share/:id —— 需登录（Cookie 中 wl_token）；未登录跳转登录页
    svr.Get(R"(/share/([A-Za-z0-9]+))", [&](const httplib::Request& req, httplib::Response& res) {
        std::string sid = req.matches[1].str();
        long long ownerUid = 0, logId = 0;
        {
            std::lock_guard<std::mutex> lk(g_db_mtx);
            Stmt s("SELECT user_id, log_id FROM shares WHERE share_id=?");
            s.bindStr(1, sid);
            if (!s.step()) { res.status = 404; res.set_content("分享链接不存在或已撤销", "text/plain; charset=utf-8"); return; }
            ownerUid = s.colInt(0); logId = s.colInt(1);
        }
        if (authUser(req) == 0) {
            res.set_redirect("/#/login?redirect=%2Fshare%2F" + sid); // share_id 为字母数字，无需再编码
            return;
        }
        (void)ownerUid;
        LogData d;
        { // 按 log_id 直接加载
            std::lock_guard<std::mutex> lk(g_db_mtx);
            Stmt s("SELECT user_id, log_date, progress_md, suggestion_md FROM daily_logs WHERE id=?");
            s.bindInt(1, logId);
            if (s.step()) {
                d.found = true; d.user_id = s.colInt(0); d.date = s.colStr(1);
                d.progress = s.colStr(2); d.suggestion = s.colStr(3); d.log_id = logId;
            }
        }
        if (!d.found) { res.status = 404; res.set_content("日报已被删除", "text/plain; charset=utf-8"); return; }
        {
            std::lock_guard<std::mutex> lk(g_db_mtx);
            Stmt u("SELECT username FROM users WHERE id=?");
            u.bindInt(1, d.user_id);
            if (u.step()) d.author = u.colStr(0);
            Stmt g("SELECT g.title FROM log_goals lg JOIN goals g ON g.id=lg.goal_id WHERE lg.log_id=?");
            g.bindInt(1, logId);
            while (g.step()) d.goals.push_back(g.colStr(0));
        }
        std::string html = buildReportHtml("工作日报 " + d.date, d.date, d.author, d.progress, d.suggestion, d.goals);
        res.set_content(html, "text/html; charset=utf-8");
    });

    // ---- 设置与工作文件夹 ----
    svr.Get("/api/settings/workfolder", [&](const httplib::Request& req, httplib::Response& res) {
        long long uid; if (!checkAuth(req, res, uid)) return;
        std::lock_guard<std::mutex> lk(g_db_mtx);
        Stmt s("SELECT value FROM settings WHERE user_id=? AND key='workfolder'");
        s.bindInt(1, uid);
        std::string path = s.step() ? s.colStr(0) : "";
        Json j = Json::makeObj();
        j["ok"] = Json::makeBool(true);
        j["path"] = Json::makeStr(path);
        j["exists"] = Json::makeBool(!path.empty() && fs::is_directory(utf8Path(path)));
        sendJson(res, j);
    });

    svr.Put("/api/settings/workfolder", [&](const httplib::Request& req, httplib::Response& res) {
        long long uid; if (!checkAuth(req, res, uid)) return;
        bool ok; Json body = parseBody(req, ok);
        if (!ok) return sendErr(res, 400, "请求体不是合法 JSON");
        std::string path = body.getStr("path");
        bool exists = !path.empty() && fs::is_directory(utf8Path(path));
        if (!path.empty() && !exists) return sendErr(res, 400, "文件夹不存在: " + path);
        std::lock_guard<std::mutex> lk(g_db_mtx);
        Stmt s("INSERT INTO settings(user_id,key,value) VALUES(?,'workfolder',?) "
               "ON CONFLICT(user_id,key) DO UPDATE SET value=excluded.value");
        s.bindInt(1, uid); s.bindStr(2, path);
        if (!s.exec()) return sendErr(res, 500, "保存失败");
        Json j = Json::makeObj();
        j["ok"] = Json::makeBool(true);
        j["path"] = Json::makeStr(path);
        j["exists"] = Json::makeBool(exists);
        sendJson(res, j);
    });

    // GET /api/files/changed?date=YYYY-MM-DD —— 扫描工作文件夹当日改动
    svr.Get("/api/files/changed", [&](const httplib::Request& req, httplib::Response& res) {
        long long uid; if (!checkAuth(req, res, uid)) return;
        std::string date = req.has_param("date") ? req.get_param_value("date") : todayStr();
        std::string folder;
        {
            std::lock_guard<std::mutex> lk(g_db_mtx);
            Stmt s("SELECT value FROM settings WHERE user_id=? AND key='workfolder'");
            s.bindInt(1, uid);
            if (s.step()) folder = s.colStr(0);
        }
        Json j = Json::makeObj();
        j["ok"] = Json::makeBool(true);
        j["date"] = Json::makeStr(date);
        j["folder"] = Json::makeStr(folder);
        Json files = Json::makeArr();
        if (!folder.empty()) {
            std::error_code ec;
            int count = 0;
            for (auto it = fs::recursive_directory_iterator(utf8Path(folder),
                     fs::directory_options::skip_permission_denied, ec);
                 !ec && it != fs::recursive_directory_iterator(); it.increment(ec)) {
                if (count >= 500) break;
                if (!it->is_regular_file(ec) || ec) continue;
                // 跳过隐藏目录（.git 等）
                std::string fn = pathUtf8(it->path().filename());
                if (!fn.empty() && fn[0] == '.') { it.disable_recursion_pending(); continue; }
                auto ft = fs::last_write_time(it->path(), ec);
                if (ec) continue;
                auto sys = std::chrono::file_clock::to_sys(ft);
                time_t tt = std::chrono::system_clock::to_time_t(sys);
                struct tm lt;
#ifdef _WIN32
                localtime_s(&lt, &tt);
#else
                localtime_r(&tt, &lt);
#endif
                char buf[32];
                strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M", &lt);
                std::string mtime(buf);
                if (mtime.substr(0, 10) == date) {
                    Json f = Json::makeObj();
                    f["path"] = Json::makeStr(pathUtf8(fs::relative(it->path(), utf8Path(folder), ec)));
                    f["size"] = Json::makeNum((double)it->file_size(ec));
                    f["mtime"] = Json::makeStr(mtime);
                    files.push(f);
                    count++;
                }
            }
        }
        j["files"] = files;
        sendJson(res, j);
    });

    // ---- 静态文件 ----
    if (!svr.set_mount_point("/", g_cfg.public_dir)) {
        fprintf(stderr, "[警告] 前端目录不存在: %s\n", g_cfg.public_dir.c_str());
    }

    printf("=========================================\n");
    printf("  WorkLog 每日工作进展记录系统\n");
    printf("  本机访问:   http://localhost:%d\n", g_cfg.port);
    printf("  局域网访问: http://<本机IP>:%d\n", g_cfg.port);
    printf("  数据库:     %s\n", g_cfg.db_path.c_str());
    printf("=========================================\n");
    if (!svr.listen(g_cfg.host, g_cfg.port)) {
        fprintf(stderr, "[错误] 端口 %d 监听失败（可能被占用）\n", g_cfg.port);
        return 1;
    }
    sqlite3_close(g_db);
    return 0;
}
