// json.h - 极简 JSON 解析/序列化（够本项目使用；字符串按 UTF-8 原样透传）
#ifndef WORKLOG_JSON_H
#define WORKLOG_JSON_H
#include <string>
#include <vector>
#include <memory>
#include <cstdio>
#include <cstdlib>
#include <cmath>

namespace mj {

struct Json;
using JsonPtr = std::shared_ptr<Json>;

struct Json {
    enum Type { NUL, BOOL, NUM, STR, ARR, OBJ } type = NUL;
    bool b = false;
    double num = 0;
    std::string str;                 // STR: 值; OBJ: 不用
    std::vector<Json> arr;
    std::vector<std::pair<std::string, Json>> obj;

    static Json makeObj() { Json j; j.type = OBJ; return j; }
    static Json makeArr() { Json j; j.type = ARR; return j; }
    static Json makeStr(const std::string& s) { Json j; j.type = STR; j.str = s; return j; }
    static Json makeNum(double d) { Json j; j.type = NUM; j.num = d; return j; }
    static Json makeBool(bool v) { Json j; j.type = BOOL; j.b = v; return j; }

    // 对象访问
    Json& operator[](const std::string& key) {
        if (type != OBJ) { type = OBJ; }
        for (auto& kv : obj) if (kv.first == key) return kv.second;
        obj.emplace_back(key, Json());
        return obj.back().second;
    }
    const Json* find(const std::string& key) const {
        if (type != OBJ) return nullptr;
        for (auto& kv : obj) if (kv.first == key) return &kv.second;
        return nullptr;
    }
    std::string getStr(const std::string& key, const std::string& def = "") const {
        const Json* j = find(key);
        return (j && j->type == STR) ? j->str : def;
    }
    double getNum(const std::string& key, double def = 0) const {
        const Json* j = find(key);
        return (j && j->type == NUM) ? j->num : def;
    }
    bool getBool(const std::string& key, bool def = false) const {
        const Json* j = find(key);
        return (j && j->type == BOOL) ? j->b : def;
    }
    bool isNull() const { return type == NUL; }

    void push(const Json& v) { if (type != ARR) type = ARR; arr.push_back(v); }

    std::string dump() const {
        std::string out;
        dumpTo(out);
        return out;
    }

private:
    static void esc(const std::string& s, std::string& out) {
        out += '"';
        for (unsigned char c : s) {
            switch (c) {
                case '"': out += "\\\""; break;
                case '\\': out += "\\\\"; break;
                case '\n': out += "\\n"; break;
                case '\r': out += "\\r"; break;
                case '\t': out += "\\t"; break;
                case '\b': out += "\\b"; break;
                case '\f': out += "\\f"; break;
                default:
                    if (c < 0x20) { char buf[8]; snprintf(buf, 8, "\\u%04x", c); out += buf; }
                    else out += char(c);
            }
        }
        out += '"';
    }
    void dumpTo(std::string& out) const {
        switch (type) {
            case NUL: out += "null"; break;
            case BOOL: out += b ? "true" : "false"; break;
            case NUM: {
                if (std::isfinite(num) && num == std::floor(num) && std::fabs(num) < 1e15) {
                    char buf[32]; snprintf(buf, 32, "%lld", (long long)num); out += buf;
                } else {
                    char buf[32]; snprintf(buf, 32, "%.10g", num); out += buf;
                }
                break;
            }
            case STR: esc(str, out); break;
            case ARR: {
                out += '[';
                for (size_t i = 0; i < arr.size(); i++) { if (i) out += ','; arr[i].dumpTo(out); }
                out += ']';
                break;
            }
            case OBJ: {
                out += '{';
                for (size_t i = 0; i < obj.size(); i++) {
                    if (i) out += ',';
                    esc(obj[i].first, out);
                    out += ':';
                    obj[i].second.dumpTo(out);
                }
                out += '}';
                break;
            }
        }
    }
};

struct ParseError {};

class Parser {
public:
    explicit Parser(const std::string& s) : s_(s), i_(0) {}
    Json parse() {
        skipWs();
        Json j = parseValue();
        return j;
    }
private:
    const std::string& s_;
    size_t i_;
    void skipWs() { while (i_ < s_.size() && (s_[i_]==' '||s_[i_]=='\t'||s_[i_]=='\n'||s_[i_]=='\r')) i_++; }
    char peek() { if (i_ >= s_.size()) throw ParseError(); return s_[i_]; }
    Json parseValue() {
        char c = peek();
        if (c == '{') return parseObj();
        if (c == '[') return parseArr();
        if (c == '"') return Json::makeStr(parseStr());
        if (c == 't') { expect("true"); return Json::makeBool(true); }
        if (c == 'f') { expect("false"); return Json::makeBool(false); }
        if (c == 'n') { expect("null"); return Json(); }
        return parseNum();
    }
    void expect(const char* w) {
        size_t n = strlen(w);
        if (i_ + n > s_.size() || s_.compare(i_, n, w)) throw ParseError();
        i_ += n;
    }
    Json parseObj() {
        Json j = Json::makeObj();
        i_++; // {
        skipWs();
        if (peek() == '}') { i_++; return j; }
        while (true) {
            skipWs();
            std::string key = parseStr();
            skipWs();
            if (peek() != ':') throw ParseError();
            i_++;
            skipWs();
            j[key] = parseValue();
            skipWs();
            char c = peek(); i_++;
            if (c == '}') break;
            if (c != ',') throw ParseError();
        }
        return j;
    }
    Json parseArr() {
        Json j = Json::makeArr();
        i_++; // [
        skipWs();
        if (peek() == ']') { i_++; return j; }
        while (true) {
            skipWs();
            j.push(parseValue());
            skipWs();
            char c = peek(); i_++;
            if (c == ']') break;
            if (c != ',') throw ParseError();
        }
        return j;
    }
    std::string parseStr() {
        if (peek() != '"') throw ParseError();
        i_++;
        std::string out;
        while (true) {
            if (i_ >= s_.size()) throw ParseError();
            char c = s_[i_++];
            if (c == '"') break;
            if (c != '\\') { out += c; continue; }
            char e = s_[i_++];
            switch (e) {
                case '"': out += '"'; break;
                case '\\': out += '\\'; break;
                case '/': out += '/'; break;
                case 'n': out += '\n'; break;
                case 'r': out += '\r'; break;
                case 't': out += '\t'; break;
                case 'b': out += '\b'; break;
                case 'f': out += '\f'; break;
                case 'u': {
                    if (i_ + 4 > s_.size()) throw ParseError();
                    unsigned cp = (unsigned)strtoul(s_.substr(i_, 4).c_str(), nullptr, 16);
                    i_ += 4;
                    // 代理对
                    if (cp >= 0xD800 && cp <= 0xDBFF && i_ + 6 <= s_.size() && s_[i_] == '\\' && s_[i_+1] == 'u') {
                        unsigned lo = (unsigned)strtoul(s_.substr(i_+2, 4).c_str(), nullptr, 16);
                        if (lo >= 0xDC00 && lo <= 0xDFFF) { cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00); i_ += 6; }
                    }
                    // UTF-8 编码
                    if (cp < 0x80) out += char(cp);
                    else if (cp < 0x800) { out += char(0xC0 | (cp >> 6)); out += char(0x80 | (cp & 0x3F)); }
                    else if (cp < 0x10000) { out += char(0xE0 | (cp >> 12)); out += char(0x80 | ((cp >> 6) & 0x3F)); out += char(0x80 | (cp & 0x3F)); }
                    else { out += char(0xF0 | (cp >> 18)); out += char(0x80 | ((cp >> 12) & 0x3F)); out += char(0x80 | ((cp >> 6) & 0x3F)); out += char(0x80 | (cp & 0x3F)); }
                    break;
                }
                default: throw ParseError();
            }
        }
        return out;
    }
    Json parseNum() {
        size_t st = i_;
        if (peek() == '-') i_++;
        while (i_ < s_.size() && (isdigit((unsigned char)s_[i_]) || s_[i_]=='.' || s_[i_]=='e' || s_[i_]=='E' || s_[i_]=='+' || s_[i_]=='-')) i_++;
        if (i_ == st) throw ParseError();
        return Json::makeNum(strtod(s_.substr(st, i_ - st).c_str(), nullptr));
    }
};

inline bool tryParse(const std::string& s, Json& out) {
    try { Parser p(s); out = p.parse(); return true; }
    catch (...) { return false; }
}

} // namespace mj
#endif
