# WorkLog · 每日工作进展记录系统

个人/小团队的每日工作记录工具：管理长中短期目标树，每天用 Markdown 写进展与建议，可导出或生成分享链接（对方登录后即可查看）。

**技术栈**：C++20 后端（cpp-httplib + SQLite，单可执行文件）+ 原生 HTML/JS 前端，数据全部存在一个 `worklog.db` 文件里，备份即复制。

## 功能

- 多用户注册/登录，数据按用户隔离
- 目标管理：长期/中期/短期三级目标，树形层级（parent 关联），起止日期、完成状态、逾期提醒
- 每日日报：Markdown 编写「今日进展」「建议」，实时预览，可勾选关联的目标
- 工作文件夹：指定一个目录，写日报时侧栏列出当天改动过的文件，一键插入进展
- 历史回顾：按月浏览任意一天的日报（渲染后展示）
- 导出：单日日报导出为 `.md` 或自包含 `.html` 文件
- 分享：生成随机链接 `/share/xxxx`，任何已登录用户凭链接可查看；可随时撤销

## Windows 构建（二选一）

### 方式 A：MinGW-w64（推荐，双击即可）

1. 安装 [MSYS2](https://www.msys2.org/)，在其中执行 `pacman -S mingw-w64-ucrt-x86_64-gcc`
2. 双击 `build.bat`（会自动找到 MSYS2 的 ucrt64/mingw64 编译器，无需手动配 PATH；首次编译 sqlite3.c 约 1-2 分钟）
3. 生成 `worklog-server.exe`

### 方式 B：CMake + Visual Studio

```bat
cmake -B build
cmake --build build --config Release
```

产物在 `build\Release\worklog-server.exe`（public 目录和 config.json 会自动拷贝到旁边）。

## 运行

双击 `worklog-server.exe`（或在项目根目录命令行运行），然后浏览器打开：

- 本机：<http://localhost:8080>
- 局域网其他设备：`http://<你电脑的IP>:8080`（用 `ipconfig` 查 IP；需在 Windows 防火墙放行该程序或 8080 端口）

首次使用先「注册」一个账号。

## 配置（config.json）

| 字段 | 默认 | 说明 |
|---|---|---|
| port | 8080 | 监听端口 |
| host | 0.0.0.0 | 监听地址（保持默认即可局域网访问） |
| db_path | data/worklog.db | 数据库文件位置 |
| public_dir | public | 前端目录 |
| token_days | 7 | 登录有效期（天） |

## 部署到公网（后续可选）

当前版本按"本机/局域网"设计。若要暴露到公网：

1. 必须置于 HTTPS 反向代理之后（Nginx/Caddy），否则密码与 token 明文传输
2. 建议配置防火墙/安全组白名单
3. 常驻运行可用 Windows 计划任务或 [NSSM](https://nssm.cc/) 注册为服务

## 目录结构

```
worklog/
├── server/
│   ├── main.cpp          # 后端全部逻辑（路由/认证/业务）
│   ├── json.h            # 极简 JSON 解析/序列化
│   ├── sha256.h          # SHA-256（密码加盐哈希）
│   └── third_party/      # httplib.h、sqlite3.c/h（第三方源码，已内置）
├── public/               # 前端 SPA
│   ├── index.html  app.js  style.css
│   └── vendor/marked.min.js
├── config.json           # 运行配置
├── Makefile              # Linux/macOS 构建
├── CMakeLists.txt        # 跨平台构建
└── build.bat             # Windows MinGW 一键构建
```

## 已知边界

- 分享页/预览用 marked.js 渲染 Markdown，未做 HTML 消毒（多用户互信场景可接受；若开放注册给陌生人，建议后续引入 DOMPurify）
- 文件扫描跳过以 `.` 开头的隐藏文件/目录，单次最多列 500 个文件
- Linux/macOS 下用 `make && ./worklog-server` 运行（开发调试用）
