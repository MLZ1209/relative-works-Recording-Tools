@echo off
rem WorkLog Windows build script (MinGW-w64 g++ required)
rem Auto-detects g++ in PATH, MSYS2 ucrt64, or MSYS2 mingw64
setlocal enabledelayedexpansion

set "GXX=g++"
set "GCC=gcc"
where g++ >nul 2>nul
if errorlevel 1 (
    if exist "C:\msys64\ucrt64\bin\g++.exe" (
        set "GXX=C:\msys64\ucrt64\bin\g++.exe"
        set "GCC=C:\msys64\ucrt64\bin\gcc.exe"
        set "PATH=C:\msys64\ucrt64\bin;%PATH%"
        echo [INFO] Using MSYS2 ucrt64 toolchain.
    ) else if exist "C:\msys64\mingw64\bin\g++.exe" (
        set "GXX=C:\msys64\mingw64\bin\g++.exe"
        set "GCC=C:\msys64\mingw64\bin\gcc.exe"
        set "PATH=C:\msys64\mingw64\bin;%PATH%"
        echo [INFO] Using MSYS2 mingw64 toolchain.
    ) else (
        echo [ERROR] g++ not found.
        echo Please install MSYS2 ^(https://www.msys2.org/^) and run:
        echo     pacman -S mingw-w64-ucrt-x86_64-gcc
        echo Or build with CMake + Visual Studio:
        echo     cmake -B build ^&^& cmake --build build --config Release
        pause
        exit /b 1
    )
)

cd /d "%~dp0"
if not exist build mkdir build

echo [1/2] Compiling sqlite3.c ^(first time takes 1-2 minutes^)...
"%GCC%" -O2 -c server\third_party\sqlite3.c -o build\sqlite3.o
if errorlevel 1 (
    echo [ERROR] sqlite3.c compile failed.
    pause
    exit /b 1
)

echo [2/2] Compiling main.cpp...
"%GXX%" -std=c++20 -O2 -static -Iserver server\main.cpp build\sqlite3.o -lws2_32 -lcrypt32 -o worklog-server.exe
if errorlevel 1 (
    echo [ERROR] main.cpp compile failed.
    pause
    exit /b 1
)

echo.
echo =========================================
echo  Build OK!  Run worklog-server.exe, then
echo  open http://localhost:8080 in browser.
echo =========================================
pause
