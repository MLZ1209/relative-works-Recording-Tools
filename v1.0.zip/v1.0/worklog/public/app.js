/* WorkLog 前端逻辑（原生 JS 单页应用） */
'use strict';

const $ = (id) => document.getElementById(id);
const state = {
  token: localStorage.getItem('wl_token') || '',
  username: localStorage.getItem('wl_user') || '',
  goals: [],
  month: new Date().toISOString().slice(0, 7),
  historyDate: null,
  editingGoalId: null,
  loginRedirect: null,
};

/* ---------- 基础 ---------- */
function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.remove('hidden');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.add('hidden'), 2200);
}

async function api(path, method = 'GET', body = null) {
  const headers = {};
  if (state.token) headers['Authorization'] = 'Bearer ' + state.token;
  if (method !== 'GET') headers['Content-Type'] = 'application/json';
  const payload = body === null ? (method !== 'GET' ? '{}' : undefined) : JSON.stringify(body);
  const res = await fetch(path, { method, headers, body: payload });
  let data = null;
  try { data = await res.json(); } catch (e) { /* 非 JSON */ }
  if (res.status === 401) { doLogout(false); throw new Error((data && data.error) || '请先登录'); }
  if (!res.ok) throw new Error((data && data.error) || ('请求失败 HTTP ' + res.status));
  return data;
}

function todayStr() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
}

function esc(s) {
  return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function md(src) {
  if (!src || !src.trim()) return '<div class="empty-tip">（无内容）</div>';
  return marked.parse(src);
}

const LEVEL_NAME = { long: '长期', mid: '中期', short: '短期' };

/* ---------- 登录 ---------- */
let loginMode = 'login';

function showLogin(redirect) {
  state.loginRedirect = redirect || null;
  $('login-view').classList.remove('hidden');
  $('app-view').classList.add('hidden');
}

function showApp() {
  $('login-view').classList.add('hidden');
  $('app-view').classList.remove('hidden');
  $('whoami').textContent = state.username;
  route();
}

function doLogout(callApi = true) {
  if (callApi && state.token) api('/api/logout', 'POST').catch(() => {});
  state.token = ''; state.username = '';
  localStorage.removeItem('wl_token'); localStorage.removeItem('wl_user');
  location.hash = '';
  showLogin();
}

async function submitLogin() {
  const u = $('login-user').value.trim(), p = $('login-pass').value;
  $('login-msg').textContent = '';
  if (!u || !p) { $('login-msg').textContent = '请输入用户名和密码'; return; }
  try {
    const path = loginMode === 'login' ? '/api/login' : '/api/register';
    let data = await api(path, 'POST', { username: u, password: p });
    if (loginMode === 'register') {
      toast('注册成功，正在登录…');
      data = await api('/api/login', 'POST', { username: u, password: p });
    }
    state.token = data.token; state.username = data.username;
    localStorage.setItem('wl_token', data.token);
    localStorage.setItem('wl_user', data.username);
    $('login-pass').value = '';
    if (state.loginRedirect) { location.href = state.loginRedirect; state.loginRedirect = null; return; }
    location.hash = '#/today';
    showApp();
  } catch (e) { $('login-msg').textContent = e.message; }
}

/* ---------- 路由 ---------- */
function route() {
  const hash = location.hash || '#/today';
  let view = 'today';
  if (hash.startsWith('#/goals')) view = 'goals';
  else if (hash.startsWith('#/history')) view = 'history';
  for (const v of ['goals', 'today', 'history']) {
    $('view-' + v).classList.toggle('hidden', v !== view);
  }
  document.querySelectorAll('.nav a').forEach(a => a.classList.toggle('active', a.dataset.view === view));
  if (view === 'goals') loadGoals();
  if (view === 'today') initToday();
  if (view === 'history') loadHistory();
}

/* ---------- 目标视图 ---------- */
async function loadGoals() {
  try {
    const data = await api('/api/goals');
    state.goals = data.goals;
    renderGoalTree();
  } catch (e) { toast(e.message); }
}

function renderGoalTree() {
  const filter = $('goal-filter').value;
  const goals = state.goals.filter(g => filter === 'all' || g.status === filter);
  const ids = new Set(goals.map(g => g.id));
  const byParent = {};
  for (const g of goals) {
    const pid = (g.parent_id && ids.has(g.parent_id)) ? g.parent_id : 0;
    (byParent[pid] = byParent[pid] || []).push(g);
  }
  const build = (pid) => {
    const list = byParent[pid] || [];
    if (!list.length) return '';
    let html = '<ul>';
    for (const g of list) {
      const due = g.due_date ? (g.due_date < todayStr() && g.status === 'active'
        ? `<span class="overdue">已逾期 ${esc(g.due_date)}</span>` : `截止 ${esc(g.due_date)}`) : '';
      const range = g.start_date ? `${esc(g.start_date)} → ` : '';
      html += `<li><div class="goal-node ${g.status === 'done' ? 'done' : ''}">
        <span class="badge ${esc(g.level)}">${LEVEL_NAME[g.level] || g.level}</span>
        <span class="goal-title">${esc(g.title)}</span>
        <span class="goal-meta">${range}${due}${g.description ? ' · ' + esc(g.description.slice(0, 40)) : ''}</span>
        <span class="goal-actions">
          <button class="btn tiny" onclick="toggleGoalStatus(${g.id})">${g.status === 'done' ? '重新打开' : '标记完成'}</button>
          <button class="btn tiny" onclick="editGoal(${g.id})">编辑</button>
          <button class="btn tiny danger" onclick="deleteGoal(${g.id})">删除</button>
        </span>
      </div>${build(g.id)}</li>`;
    }
    return html + '</ul>';
  };
  const html = build(0);
  $('goal-tree').innerHTML = html || '<div class="empty-tip">还没有目标，点击右上角「新增目标」开始规划</div>';
}

function openGoalModal(goal) {
  state.editingGoalId = goal ? goal.id : null;
  $('goal-modal-title').textContent = goal ? '编辑目标' : '新增目标';
  $('gm-title').value = goal ? goal.title : '';
  $('gm-level').value = goal ? goal.level : 'short';
  $('gm-start').value = goal ? (goal.start_date || '') : '';
  $('gm-due').value = goal ? (goal.due_date || '') : '';
  $('gm-desc').value = goal ? (goal.description || '') : '';
  $('gm-msg').textContent = '';
  // 上级目标下拉（排除自己，防止自环）
  const sel = $('gm-parent');
  sel.innerHTML = '<option value="">（无，作为顶级目标）</option>';
  for (const g of state.goals) {
    if (goal && g.id === goal.id) continue;
    const opt = document.createElement('option');
    opt.value = g.id;
    opt.textContent = `[${LEVEL_NAME[g.level] || g.level}] ${g.title}`;
    if (goal && goal.parent_id === g.id) opt.selected = true;
    sel.appendChild(opt);
  }
  $('goal-modal').classList.remove('hidden');
}

async function saveGoalModal() {
  const title = $('gm-title').value.trim();
  if (!title) { $('gm-msg').textContent = '标题不能为空'; return; }
  const body = {
    title,
    level: $('gm-level').value,
    parent_id: $('gm-parent').value ? Number($('gm-parent').value) : null,
    start_date: $('gm-start').value,
    due_date: $('gm-due').value,
    description: $('gm-desc').value,
  };
  try {
    if (state.editingGoalId) await api('/api/goals/' + state.editingGoalId, 'PUT', body);
    else await api('/api/goals', 'POST', body);
    $('goal-modal').classList.add('hidden');
    toast('已保存');
    loadGoals();
  } catch (e) { $('gm-msg').textContent = e.message; }
}

window.editGoal = (id) => openGoalModal(state.goals.find(g => g.id === id));
window.deleteGoal = async (id) => {
  if (!confirm('确定删除该目标？其子目标将上移一级，日报中的关联会解除。')) return;
  try { await api('/api/goals/' + id, 'DELETE'); toast('已删除'); loadGoals(); }
  catch (e) { toast(e.message); }
};
window.toggleGoalStatus = async (id) => {
  const g = state.goals.find(x => x.id === id);
  try {
    await api('/api/goals/' + id, 'PUT', { status: g.status === 'done' ? 'active' : 'done' });
    loadGoals();
  } catch (e) { toast(e.message); }
};

/* ---------- 今日日报 ---------- */
let todayInited = false;

async function initToday() {
  if (!todayInited) {
    $('log-date').value = todayStr();
    $('log-date').addEventListener('change', loadLogForDate);
    ['log-progress', 'log-suggestion'].forEach(id =>
      $(id).addEventListener('input', updatePreview));
    todayInited = true;
  }
  await loadLogForDate();
  loadWorkfolder();
  loadChangedFiles();
}

function updatePreview() {
  $('preview-progress').innerHTML = md($('log-progress').value);
  $('preview-suggestion').innerHTML = md($('log-suggestion').value);
}

async function loadLogForDate() {
  const date = $('log-date').value || todayStr();
  try {
    const data = await api('/api/logs/' + date);
    $('log-progress').value = data.progress_md || '';
    $('log-suggestion').value = data.suggestion_md || '';
    renderGoalChecks(data.goal_ids || []);
    updatePreview();
    $('save-state').textContent = data.found ? '已有记录' : '';
  } catch (e) { toast(e.message); }
}

function renderGoalChecks(checkedIds) {
  const box = $('log-goal-checks');
  const actives = state.goals.filter(g => g.status === 'active');
  if (!actives.length && !state.goals.length) {
    box.innerHTML = '<span class="empty-tip" style="padding:4px">暂无目标，可先到「目标」页添加</span>';
    return;
  }
  box.innerHTML = actives.length ? actives.map(g => `
    <label class="goal-check">
      <input type="checkbox" value="${g.id}" ${checkedIds.includes(g.id) ? 'checked' : ''}>
      <span class="badge ${esc(g.level)}" style="padding:0 6px">${LEVEL_NAME[g.level] || ''}</span> ${esc(g.title)}
    </label>`).join('') : '<span class="empty-tip" style="padding:4px">没有进行中的目标</span>';
  // 已勾选但已完成的目标也显示
  for (const id of checkedIds) {
    const g = state.goals.find(x => x.id === id && x.status === 'done');
    if (g) box.insertAdjacentHTML('beforeend', `
      <label class="goal-check"><input type="checkbox" value="${g.id}" checked>
      <span class="badge ${esc(g.level)}" style="padding:0 6px">${LEVEL_NAME[g.level] || ''}</span> ${esc(g.title)}（已完成）</label>`);
  }
}

async function saveLog() {
  const date = $('log-date').value || todayStr();
  const goalIds = [...document.querySelectorAll('#log-goal-checks input:checked')].map(x => Number(x.value));
  try {
    await api('/api/logs/' + date, 'POST', {
      progress_md: $('log-progress').value,
      suggestion_md: $('log-suggestion').value,
      goal_ids: goalIds,
    });
    $('save-state').textContent = '已保存 ' + new Date().toTimeString().slice(0, 8);
    toast('日报已保存');
  } catch (e) { toast(e.message); }
}

/* 工作文件夹与文件改动 */
async function loadWorkfolder() {
  try {
    const d = await api('/api/settings/workfolder');
    $('workfolder-input').value = d.path || '';
    $('workfolder-msg').textContent = d.path ? (d.exists ? '✓ 文件夹有效' : '⚠ 文件夹不存在') : '';
  } catch (e) { /* 忽略 */ }
}

async function saveWorkfolder() {
  const path = $('workfolder-input').value.trim();
  try {
    const d = await api('/api/settings/workfolder', 'PUT', { path });
    $('workfolder-msg').textContent = d.path ? '✓ 已保存' : '已清空';
    loadChangedFiles();
  } catch (e) { $('workfolder-msg').textContent = e.message; }
}

async function loadChangedFiles() {
  const date = $('log-date').value || todayStr();
  const box = $('changed-files');
  try {
    const d = await api('/api/files/changed?date=' + date);
    if (!d.folder) { box.innerHTML = '<div class="empty-tip">先设置工作文件夹</div>'; return; }
    if (!d.files.length) { box.innerHTML = '<div class="empty-tip">该日期无文件改动</div>'; return; }
    box.innerHTML = d.files.map((f, i) => `
      <div class="file-item">
        <span class="fpath" title="${esc(f.path)}">${esc(f.path)}</span>
        <span class="ftime">${esc(f.mtime.slice(11))}</span>
        <button class="btn tiny" onclick="insertFile(${i})">插入</button>
      </div>`).join('');
    box._files = d.files;
  } catch (e) { box.innerHTML = '<div class="empty-tip">' + esc(e.message) + '</div>'; }
}

window.insertFile = (i) => {
  const f = $('changed-files')._files[i];
  const ta = $('log-progress');
  ta.value += (ta.value && !ta.value.endsWith('\n') ? '\n' : '') + '- 修改了 `' + f.path + '`\n';
  updatePreview();
  toast('已插入到进展');
};

/* ---------- 历史回顾 ---------- */
async function loadHistory() {
  $('month-label').textContent = state.month;
  try {
    const d = await api('/api/logs/list?month=' + state.month);
    const box = $('history-list');
    box.innerHTML = d.dates.length ? d.dates.map(dt => `
      <div class="hist-date ${dt === state.historyDate ? 'active' : ''}" onclick="showHistoryDetail('${dt}')">
        <span>${dt}</span><span>${weekday(dt)}</span>
      </div>`).join('') : '<div class="empty-tip">本月还没有日报</div>';
    if (state.historyDate && d.dates.includes(state.historyDate)) showHistoryDetail(state.historyDate);
  } catch (e) { toast(e.message); }
}

function weekday(dt) {
  return '周' + '日一二三四五六'[new Date(dt + 'T00:00:00').getDay()];
}

window.showHistoryDetail = async (date) => {
  state.historyDate = date;
  document.querySelectorAll('.hist-date').forEach(el =>
    el.classList.toggle('active', el.textContent.trim().startsWith(date)));
  const box = $('history-detail');
  box.innerHTML = '<div class="empty-tip">加载中…</div>';
  try {
    const d = await api('/api/logs/' + date);
    const goals = state.goals.filter(g => (d.goal_ids || []).includes(g.id));
    const shareUrl = d.share_id ? location.origin + '/share/' + d.share_id : '';
    box.innerHTML = `
      <h3>${date}（${weekday(date)}）</h3>
      <div class="detail-actions">
        <button class="btn small" onclick="exportLog('${date}','md')">导出 Markdown</button>
        <button class="btn small" onclick="exportLog('${date}','html')">导出 HTML</button>
        ${d.share_id
          ? `<button class="btn small" onclick="copyShare('${shareUrl}')">复制分享链接</button>
             <button class="btn small danger" onclick="revokeShare('${date}')">撤销分享</button>`
          : `<button class="btn small primary" onclick="makeShare('${date}')">生成分享链接</button>`}
      </div>
      ${shareUrl ? `<div class="share-link">分享链接（对方需登录后查看）：${esc(shareUrl)}</div>` : ''}
      ${goals.length ? `<p style="color:var(--muted);margin:10px 0 4px">关联目标：${goals.map(g => esc(g.title)).join('、')}</p>` : ''}
      <h4 style="margin:14px 0 6px">今日进展</h4>
      <div class="content">${md(d.progress_md)}</div>
      <h4 style="margin:14px 0 6px">建议</h4>
      <div class="content">${md(d.suggestion_md)}</div>`;
  } catch (e) { box.innerHTML = '<div class="empty-tip">' + esc(e.message) + '</div>'; }
};

window.exportLog = (date, fmt) => {
  window.open(`/api/logs/${date}/export?format=${fmt}&token=${encodeURIComponent(state.token)}`, '_blank');
};

window.makeShare = async (date) => {
  try { const d = await api(`/api/logs/${date}/share`, 'POST'); toast('分享链接已生成'); showHistoryDetail(date); }
  catch (e) { toast(e.message); }
};

window.revokeShare = async (date) => {
  if (!confirm('撤销后原链接将失效，确定？')) return;
  try { await api(`/api/logs/${date}/share`, 'DELETE'); toast('已撤销分享'); showHistoryDetail(date); }
  catch (e) { toast(e.message); }
};

window.copyShare = async (url) => {
  try { await navigator.clipboard.writeText(url); toast('链接已复制'); }
  catch (e) {
    prompt('复制分享链接：', url);
  }
};

/* ---------- 事件绑定与启动 ---------- */
function bindEvents() {
  $('tab-login').onclick = () => {
    loginMode = 'login';
    $('tab-login').classList.add('active'); $('tab-register').classList.remove('active');
    $('login-btn').textContent = '登 录';
  };
  $('tab-register').onclick = () => {
    loginMode = 'register';
    $('tab-register').classList.add('active'); $('tab-login').classList.remove('active');
    $('login-btn').textContent = '注册并登录';
  };
  $('login-btn').onclick = submitLogin;
  $('login-pass').addEventListener('keydown', e => { if (e.key === 'Enter') submitLogin(); });
  $('logout-btn').onclick = () => doLogout(true);
  $('goal-filter').onchange = renderGoalTree;
  $('add-goal-btn').onclick = () => openGoalModal(null);
  $('gm-cancel').onclick = () => $('goal-modal').classList.add('hidden');
  $('gm-save').onclick = saveGoalModal;
  $('save-log-btn').onclick = saveLog;
  $('workfolder-save').onclick = saveWorkfolder;
  $('refresh-files').onclick = loadChangedFiles;
  $('month-prev').onclick = () => { state.month = shiftMonth(state.month, -1); loadHistory(); };
  $('month-next').onclick = () => { state.month = shiftMonth(state.month, 1); loadHistory(); };
  window.addEventListener('hashchange', route);
}

function shiftMonth(m, delta) {
  const [y, mo] = m.split('-').map(Number);
  const d = new Date(y, mo - 1 + delta, 1);
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
}

async function boot() {
  bindEvents();
  // 预取目标（今日/历史视图都依赖）
  if (state.token) {
    try {
      const me = await api('/api/me');
      state.username = me.username;
      localStorage.setItem('wl_user', me.username);
      await loadGoals();
      // 登录回跳：#/login?redirect=/share/xxx
      const hash = location.hash;
      if (hash.startsWith('#/login?redirect=')) {
        location.href = decodeURIComponent(hash.slice('#/login?redirect='.length));
        return;
      }
      showApp();
      return;
    } catch (e) { /* token 失效 */ }
  }
  // 未登录：检查是否是分享链接回跳
  const hash = location.hash;
  if (hash.startsWith('#/login?redirect=')) {
    showLogin(decodeURIComponent(hash.slice('#/login?redirect='.length)));
  } else {
    showLogin();
  }
}

boot();
